/* Test program for fast IIR filter function */

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <siglib.h>

/* Define constants */
#define	PER_SAMPLE				0			/* Set to '1' to process on per sample basis, '0' on array */
#define	IMPULSE_RESPONSE		0			/* Set to '1' to generate the impulse response, '0' for step response */

#define IIR_FILTER_STAGES		3			/* Half the size of the filter order */
#define	IMPULSE_RESPONSE_LENGTH	((SFIX)10)	/* Length of impulse response generated */
#define COEFFS_PER_TI_BIQUAD	4			/* Number of coeffs in a TI optimised biquad */

/* Define global variables */

#pragma DATA_ALIGN(pIIRCoeffs, 8);			/* Align arrays on 64 bit boundary for LDDW */
#pragma DATA_ALIGN(pAsmIIRCoeffs, 8);
#pragma DATA_ALIGN(pFilterState, 8);
#pragma DATA_ALIGN(pInput, 8);
#pragma DATA_ALIGN(pOutput, 8);

											/* IIR biquad filter coefficients */
SFLOAT pIIRCoeffs[] = {
	 9.42380353047E-0002,  1.08526026540E-0001,  9.42380353047E-0002, -1.73648791886E+0000,  7.81845268784E-0001,
	 9.42380353047E-0002, -9.71701377691E-0002,  9.42380353047E-0002, -1.64442139918E+0000,  8.62782495425E-0001,
	 9.42380353047E-0002, -5.53439298689E-0002,  9.42380353047E-0002, -1.59154638820E+0000,  9.56063978767E-0001,
	};

SFLOAT pAsmIIRCoeffs[IIR_FILTER_STAGES * 4];


SFLOAT pFilterState [IIR_FILTER_STAGES * SIGLIB_IIR_DELAY_SIZE];
SFLOAT pInput[IMPULSE_RESPONSE_LENGTH];
SFLOAT pOutput [IMPULSE_RESPONSE_LENGTH];

SFLOAT SIGLIB_FUNC_DECL SDS_FastIir (const SFLOAT,	/* Input data sample to be filtered */
	SFLOAT * SIGLIB_PTR_DECL,				/* Pointer to filter state array */
	const SFLOAT * SIGLIB_PTR_DECL,			/* Pointer to filter coefficients array */
	const SFIX);							/* Number of stages */

void SIGLIB_FUNC_DECL SDA_FastIir (const SFLOAT * SIGLIB_PTR_DECL,	/* Input data buffer to be filtered */
	SFLOAT * SIGLIB_PTR_DECL,				/* Filtered output data buffer */
	SFLOAT * SIGLIB_PTR_DECL,				/* Pointer to filter state array */
	const SFLOAT * SIGLIB_PTR_DECL,			/* Pointer to filter coefficients array */
	const SFIX,								/* Number of stages */
	const SFIX);							/* Data array length */


	/* Prototype for assembly coded biquad function */
float biquad (int numBiquad, float *c, float *d, float y);

SFLOAT	generate_ti_iir_coeffs (const SFLOAT *pSrc, SFLOAT *pDst, const SFIX NumberOfStages);

void main (void)
{
	SFIX	i;
	SFLOAT	TI_IIR_Gain;
    clock_t t_overhead, t_start, t_stop;

					    /* Compute the overhead of calling the clock function twice, to get the timing info. */
    t_start = clock (); t_stop = clock (); t_overhead = t_stop - t_start;

	SIF_Iir (pFilterState, IIR_FILTER_STAGES);

				/* Generate test input data */
#if IMPULSE_RESPONSE
	SDA_SignalGenerate (pInput, SIGLIB_IMPULSE, SIGLIB_ONE, SIGLIB_FILL, SIGLIB_ZERO, SIGLIB_ZERO,
					SIGLIB_ZERO, SIGLIB_ZERO, SIGLIB_NULL_SFLOAT_PTR, SIGLIB_NULL_SFLOAT_PTR, IMPULSE_RESPONSE_LENGTH);
#else
	SDA_SignalGenerate (pInput, SIGLIB_STEP, SIGLIB_ONE, SIGLIB_FILL, SIGLIB_ZERO, SIGLIB_ZERO,
					SIGLIB_ZERO, SIGLIB_ZERO, SIGLIB_NULL_SFLOAT_PTR, SIGLIB_NULL_SFLOAT_PTR, IMPULSE_RESPONSE_LENGTH);
#endif

	printf ("Starting SigLib IIR filter benchmark\n");
	t_start = clock ();
				/* Apply iir filter and store filtered data */
#if PER_SAMPLE
	for (i = 0; i < IMPULSE_RESPONSE_LENGTH; i++)
		pOutput [i] = SDS_Iir (pInput [i], pFilterState, pIIRCoeffs, IIR_FILTER_STAGES);
#else
	SDA_Iir (pInput, pOutput, pFilterState, pIIRCoeffs, IIR_FILTER_STAGES, IMPULSE_RESPONSE_LENGTH);
#endif
    t_stop = clock ();
    printf ("SigLib biquad benchmark : %d cycles\n\n", t_stop - t_start - t_overhead);

	printf ("Input Data      Output Data\n");
	for (i = 0; i < IMPULSE_RESPONSE_LENGTH; i++)			// Print results
		printf ("%0.8f\t%0.8f\n", pInput[i], pOutput[i]);


	SIF_Iir (pFilterState, IIR_FILTER_STAGES);
	TI_IIR_Gain = generate_ti_iir_coeffs (pIIRCoeffs, pAsmIIRCoeffs, IIR_FILTER_STAGES);

	printf ("\nAssembly IIR filter gain = %lf\n", TI_IIR_Gain);
	printf ("Assembly IIR filter coefficients :\n");
	for (i = 0; i < IIR_FILTER_STAGES; i++)
		printf ("%lf, %lf, %lf, %lf,\n", pAsmIIRCoeffs[(i * COEFFS_PER_TI_BIQUAD)],
										 pAsmIIRCoeffs[(i * COEFFS_PER_TI_BIQUAD)+1],
										 pAsmIIRCoeffs[(i * COEFFS_PER_TI_BIQUAD)+2],
										 pAsmIIRCoeffs[(i * COEFFS_PER_TI_BIQUAD)+3]);
	printf ("\n");

	printf ("Starting assembly IIR filter benchmark\n");
	t_start = clock ();
				/* Apply iir filter and store filtered data */
#if PER_SAMPLE
	for (i = 0; i < IMPULSE_RESPONSE_LENGTH; i++)
		pOutput [i] = SDS_FastIir (pInput [i], pFilterState, pAsmIIRCoeffs, IIR_FILTER_STAGES);
#else
	SDA_FastIir (pInput, pOutput, pFilterState, pAsmIIRCoeffs, IIR_FILTER_STAGES, IMPULSE_RESPONSE_LENGTH);
#endif
    t_stop = clock ();
    printf ("Assembly coded biquad benchmark : %d cycles\n\n", t_stop - t_start - t_overhead);

	printf ("Input Data      Output Data\n");
	for (i = 0; i < IMPULSE_RESPONSE_LENGTH; i++)			// Print results
		printf ("%0.8f\t%0.8f\n", pInput[i], pOutput[i] * TI_IIR_Gain);

}


/**/
/********************************************************
* Function : SDA_FastIir
*
* Parameters :
*	const SFLOAT * SIGLIB_PTR_DECL pSrc,
*	SFLOAT * SIGLIB_PTR_DECL pDst,
*	SFLOAT * SIGLIB_PTR_DECL pState,
*	const SFLOAT * SIGLIB_PTR_DECL pCoeffs,
*	const SFIX NumberOfStages,
*	const SFIX SampleLength
*
* Return value :
*	void
*
* Description :
*	Apply assembly coded IIR filter in biquad.asm.
*	Coefficient order : -a1, -a2, b1, b2
*	The feedforward coefficients are scaled so that
*	a0 = 1.0. This results in a scaled output compared
*	to the standard IIR filter.
*	You must ensure that the coefficient and state
*	arrays are on a suitable 64 bit memory alignment.
*	This function can work "in-place" i.e. where the
*	source and destination pointers can point to the
*	same location.
*
********************************************************/

void SIGLIB_FUNC_DECL SDA_FastIir (const SFLOAT * SIGLIB_PTR_DECL pSrc,
	SFLOAT * SIGLIB_PTR_DECL pDst,
	SFLOAT * SIGLIB_PTR_DECL pState,
	const SFLOAT * SIGLIB_PTR_DECL pCoeffs,
	const SFIX NumberOfStages,
	const SFIX SampleLength)

{
	register SFIX	i;

#if (SIGLIB_ARRAYS_ALIGNED)
#ifdef _TMS320C6700							/* Defined by TI compiler */
#pragma DATA_ALIGN(pSrc, 8);				/* Align arrays on 64 bit double word boundary for LDDW */
#pragma DATA_ALIGN(pDst, 8);				/* Align arrays on 64 bit double word boundary for LDDW */
#pragma DATA_ALIGN(pState, 8);				/* Align arrays on 64 bit double word boundary for LDDW */
#endif
#endif

	for (i = 0; i < SampleLength; i++)
	{
		*pDst++ = biquad (NumberOfStages, (float *)pCoeffs, (float *)pState, *pSrc++);
	}

}	/* End of SDA_FastIir () */


/**/
/********************************************************
* Function : SDS_FastIir
*
* Parameters :
*	const SFLOAT Source sample,
*	SFLOAT * SIGLIB_PTR_DECL pState,
*	const SFLOAT * SIGLIB_PTR_DECL pCoeffs,
*	const SFIX NumberOfStages
*
* Return value :
*	SFLOAT - Filtered sample
*
* Description :
*	Apply assembly coded IIR filter in biquad.asm.
*	Coefficient order : -a1, -a2, b1, b2
*	The feedforward coefficients are scaled so that
*	a0 = 1.0. This results in a scaled output compared
*	to the standard IIR filter.
*	You must ensure that the coefficient and state
*	arrays are on a suitable 64 bit memory alignment.
*
********************************************************/

SFLOAT SIGLIB_FUNC_DECL SDS_FastIir (const SFLOAT Src,
	SFLOAT * SIGLIB_PTR_DECL pState,
	const SFLOAT * SIGLIB_PTR_DECL pCoeffs,
	const SFIX NumberOfStages)

{
	return ((SFLOAT) biquad (NumberOfStages, (float *)pCoeffs, (float *)pState, Src));
}	/* End of SDS_FastIir () */


/**/
/********************************************************
* Function : generate_ti_iir_coeffs
*
* Parameters :
*	const SFLOAT *		Source coefficients,
*	SFLOAT *			Destination coefficients,
*	const SFIX			Number of stages
*
* Return value :
*	SFLOAT - Filter scaling factor
*
* Description :
*	Calculate the IIR biquad coefficients for the
*	fast assembly coded IIR filter function.
*	This function also calcualtes and returns inverse
*	of the filter scaling factor, which is based on
*	the modification of the feedforward coefficients.
*
********************************************************/

SFLOAT	generate_ti_iir_coeffs (const SFLOAT *pSrc,
	SFLOAT *pDst,
	const SFIX NumberOfStages)

{
	SFLOAT	Gain = SIGLIB_ONE;
	SFIX	i;

	for (i = 0; i < NumberOfStages; i++)
	{
		Gain *= pSrc[i * SIGLIB_IIR_COEFFS_PER_BIQUAD];
		pDst[(i * 4)]     = -pSrc[(i * SIGLIB_IIR_COEFFS_PER_BIQUAD) + 3];
		pDst[(i * 4) + 1] = -pSrc[(i * SIGLIB_IIR_COEFFS_PER_BIQUAD) + 4];
		pDst[(i * 4) + 2] =  pSrc[(i * SIGLIB_IIR_COEFFS_PER_BIQUAD) + 1] / pSrc[i * SIGLIB_IIR_COEFFS_PER_BIQUAD];
		pDst[(i * 4) + 3] =  pSrc[(i * SIGLIB_IIR_COEFFS_PER_BIQUAD) + 2] / pSrc[i * SIGLIB_IIR_COEFFS_PER_BIQUAD];
	}

	return (Gain);
}


