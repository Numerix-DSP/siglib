/* C Code Benchmark Program
	Real dot product
	Complex dot product
	IIR biquad 

Notes :
There are two different versions of the complex dot product and these
show that there is no performance difference in the piped loop kernel
when using the complex structure or the interleaved float procedure.

There are two different versions of the IIR biquad that change the
processing slightly. The second method is the more efficient.
The IIR biquads are scaled so that a0 = 1.0

Results :
TMS320C67x :
	Real dot product : 4 cycle kernel with 4 MACs
	Complex dot product #1 and 2: 4 cycles per complex MAC
		Note - The compiler did not like the complex data types
	Complex dot product #3: 4 cycles per PAIR of complex MACs
	Biquad 1 : 8 cycles per biquad
	Biquad 2 : 4 cycles per biquad

ADSP2116x :
	Real dot product : 1 cycle per real MAC
	Complex dot product #1 and 2: 6 cycles per complex MAC
		Note - The compiler did not like the complex data types
	Complex dot product #3: 4 cycles per PAIR of complex MACs
	Biquad 1 : 4 cycles per biquad
	Biquad 2 : 3 cycles per biquad

Written by :
	John Edwards, Numerix Ltd.
	jedwards@numerix-dsp.com
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// The pm memory declaration is SHARC specific
#if defined (__2106x__) || defined (__2116x__) || defined (__ADSPTS__)		/* Defined by ADI VisualDSP++ compiler */
#define ENABLE_SHARC	1
#else
#define pm /**/
#endif

		/* Parameters for real dot product */
#define REAL_DOTP_LENGTH 32

#if defined (_TMS320C6700)			/* Defined by TI compiler */
#pragma DATA_ALIGN(a, 8);			/* Align arrays on 64 bit boundary for LDDW */
#elif defined (ENABLE_SHARC)
#pragma align 8
#endif
float pm a[] = {
   1.0, 2.0, 3.0, 4.0, 5.0, 1.0, 2.0, 3.0, 4.0, 5.0,
   1.0, 2.0, 3.0, 4.0, 5.0, 1.0, 2.0, 3.0, 4.0, 5.0
};

#if defined (_TMS320C6700)			/* Defined by TI compiler */
#pragma DATA_ALIGN(b, 8);			/* Align arrays on 64 bit boundary for LDDW */
#elif defined (ENABLE_SHARC)
#pragma align 8
#endif
float b[] = {
   1.0, 2.0, 3.0, 4.0, 5.0, 1.0, 2.0, 3.0, 4.0, 5.0,
   1.0, 2.0, 3.0, 4.0, 5.0, 1.0, 2.0, 3.0, 4.0, 5.0
};

		/* Parameters for complex dot product */
typedef struct	{
	float	real;
	float	imaginary;
	} ComplexData_t;

#define CPLX_DOTP_LENGTH 20

#if defined (_TMS320C6700)			/* Defined by TI compiler */
#pragma DATA_ALIGN(input1, 8);			/* Align arrays on 64 bit boundary for LDDW */
#elif defined (ENABLE_SHARC)
#pragma align 8
#endif
static ComplexData_t pm input1[CPLX_DOTP_LENGTH] = {
	{1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0},
	{1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0},
	{1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0},
	{1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}
};

#if defined (_TMS320C6700)			/* Defined by TI compiler */
#pragma DATA_ALIGN(input2, 8);			/* Align arrays on 64 bit boundary for LDDW */
#elif defined (ENABLE_SHARC)
#pragma align 8
#endif
static ComplexData_t input2[CPLX_DOTP_LENGTH] = {
	{1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0},
	{1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0},
	{1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0},
	{1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}, {1.0, 2.0}
};

#if defined (_TMS320C6700)			/* Defined by TI compiler */
#pragma DATA_ALIGN(RealInput1, 8);			/* Align arrays on 64 bit boundary for LDDW */
#elif defined (ENABLE_SHARC)
#pragma align 8
#endif
static ComplexData_t pm RealInput1[CPLX_DOTP_LENGTH] = {
	1.0, 1.0, 1.0, 1.0, 1.0,
	1.0, 1.0, 1.0, 1.0, 1.0,
	1.0, 1.0, 1.0, 1.0, 1.0,
	1.0, 1.0, 1.0, 1.0, 1.0
};

#if defined (_TMS320C6700)			/* Defined by TI compiler */
#pragma DATA_ALIGN(ImagInput1, 8);			/* Align arrays on 64 bit boundary for LDDW */
#elif defined (ENABLE_SHARC)
#pragma align 8
#endif
static ComplexData_t pm ImagInput1[CPLX_DOTP_LENGTH] = {
	2.0, 2.0, 2.0, 2.0, 2.0,
	2.0, 2.0, 2.0, 2.0, 2.0,
	2.0, 2.0, 2.0, 2.0, 2.0,
	2.0, 2.0, 2.0, 2.0, 2.0
};

#if defined (_TMS320C6700)			/* Defined by TI compiler */
#pragma DATA_ALIGN(RealInput2, 8);			/* Align arrays on 64 bit boundary for LDDW */
#elif defined (ENABLE_SHARC)
#pragma align 8
#endif
static ComplexData_t RealInput2[CPLX_DOTP_LENGTH] = {
	1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
	1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0
};
#if defined (_TMS320C6700)			/* Defined by TI compiler */
#pragma DATA_ALIGN(ImagInput2, 8);			/* Align arrays on 64 bit boundary for LDDW */
#elif defined (ENABLE_SHARC)
#pragma align 8
#endif
static ComplexData_t ImagInput2[CPLX_DOTP_LENGTH] = {
	2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0,
	2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0
};

		/* Parameters for IIR filter */
#define NUM_BIQUADS		10

#if defined (_TMS320C6700)			/* Defined by TI compiler */
#pragma DATA_ALIGN(IIRCoeffArray, 8);			/* Align arrays on 64 bit boundary for LDDW */
#elif defined (ENABLE_SHARC)
#pragma align 8
#endif
float pm IIRCoeffArray[] = {					/* Enough for 10 biquads */
	1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0,
	11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0,
	21.0, 22.0, 23.0, 24.0, 25.0, 26.0, 27.0, 28.0, 29.0, 30.0,
	31.0, 32.0, 33.0, 34.0, 35.0, 36.0, 37.0, 38.0, 39.0, 40.0,
	};

float IIRStatePtr[NUM_BIQUADS*2];

		/* Function prototypes */
float DotP (const float pm *, const float *, int ); 

ComplexData_t ComplexDotP(const ComplexData_t pm *, const ComplexData_t *, const int);
ComplexData_t ComplexDotP2(const float pm *, const float *, const int);
ComplexData_t ComplexDotP3 (pm const float *,
	pm const float *,
	const float *,
	const float *,
	const int);

float biquad1 (const float pm *, float *, const int, float y);
float biquad2 (const float pm *, float *, const int, float y);


void main()
{
	float			Result;
	ComplexData_t	ComplexResult;
    float			IIRSrcData = 3.2;
	int				i;

    Result = DotP ( a, b, REAL_DOTP_LENGTH );
    printf( "Dot product = %f\n\n", Result);

	ComplexResult = ComplexDotP (input1, input2, CPLX_DOTP_LENGTH);
    printf( "Complex Dot product #1 = %f + j%f\n\n", ComplexResult.real, ComplexResult.imaginary);

	ComplexResult = ComplexDotP2 ((const pm float *)input1, (const float *)input2, CPLX_DOTP_LENGTH);
    printf( "Complex Dot product #2 = %f + j%f\n\n", ComplexResult.real, ComplexResult.imaginary);

	ComplexResult = ComplexDotP3 ((const pm float *)RealInput1, (const pm float *)ImagInput1,
				(const float *)RealInput2, (const float *)ImagInput2, CPLX_DOTP_LENGTH);
    printf( "Complex Dot product #3 = %f + j%f\n\n", ComplexResult.real, ComplexResult.imaginary);

	for (i = 0; i < NUM_BIQUADS*2; i++)		/* Initialise IIR state array */
		IIRStatePtr[i] = 0.0;

	for (i = 0; i < 4; i++)
		Result = biquad1 (IIRCoeffArray, IIRStatePtr, NUM_BIQUADS, IIRSrcData);
    printf ("Biquad 1 result : %f\n\n", Result);

	for (i = 0; i < NUM_BIQUADS*2; i++)		/* Initialise IIR state array */
		IIRStatePtr[i] = 0.0;

	for (i = 0; i < 4; i++)
		Result = biquad2 (IIRCoeffArray, IIRStatePtr, NUM_BIQUADS, IIRSrcData);
    printf ("Biquad 2 result : %f\n\n", Result);

}


float DotP (const float pm * restrict a, const float * restrict b, int length)
{
    int i;
    float output = 0.0;

#if defined (_TMS320C6700)			/* Defined by TI compiler */
_nassert (((int)(a) & 0x7) == 0);	/* Float array aligned on 64-bit boundary */
_nassert (((int)(b) & 0x7) == 0);	/* Float array aligned on 64-bit boundary */
#pragma MUST_ITERATE (16, , 8);		/* Minimum trip count and execute multiple of 8 times */
#elif ENABLE_SHARC
#pragma SIMD_for
#endif
	for( i=0; i < length; i++ ) 
    {
		output += ( a[i] * b[i] );
	}

    return( output );
}

ComplexData_t ComplexDotP (const ComplexData_t pm * restrict p_Input1,
	const ComplexData_t * restrict p_Input2,
	const int count)

{
	int					i;
	ComplexData_t		Mac;

	Mac.real = 0.0;
	Mac.imaginary = 0.0;

#if defined (_TMS320C6700)			/* Defined by TI compiler */
_nassert (((int)(p_Input1) & 0x7) == 0);	/* Float array aligned on 64-bit boundary */
_nassert (((int)(p_Input2) & 0x7) == 0);
#pragma MUST_ITERATE (16, , 8);
#elif ENABLE_SHARC
#pragma SIMD_for
#endif

	for (i = 0; i < count; i++)
	{
		Mac.real += (p_Input1[i].real * p_Input2[i].real) -
			(p_Input1[i].imaginary * p_Input2[i].imaginary);
		Mac.imaginary += (p_Input1[i].real * p_Input2[i].imaginary) +
			(p_Input1[i].imaginary * p_Input2[i].real);
	}

	return (Mac);
}


ComplexData_t ComplexDotP2 (pm const float * restrict p_Input1,
	const float * restrict p_Input2,
	const int count)
{
	int				i;
	float			RealSum, ImagSum;
	ComplexData_t	ReturnValue;

	RealSum = 0.0;
	ImagSum = 0.0;

#if defined (_TMS320C6700)			/* Defined by TI compiler */
_nassert (((int)(p_Input1) & 0x7) == 0);	/* Float array aligned on 64-bit boundary */
_nassert (((int)(p_Input2) & 0x7) == 0);
#pragma MUST_ITERATE (16, , 8);
#elif ENABLE_SHARC
#pragma SIMD_for
#endif

	for (i = 0; i < (count << 1); i += 2)
	{
	/* Real components are at even offsets, and imaginary components
	are at odd offsets within each array. */
		RealSum += (p_Input1[i] * p_Input2[i] - p_Input1[i+1] * p_Input2[i+1]);
		ImagSum += (p_Input1[i] * p_Input2[i+1] + p_Input1[i+1] * p_Input2[i]);
	}
	ReturnValue.real = RealSum;
	ReturnValue.imaginary = ImagSum;

	return (ReturnValue);
	
}


ComplexData_t ComplexDotP3 (pm const float * restrict p_RealInput1,
	pm const float * restrict p_ImagInput1,
	const float * restrict p_RealInput2,
	const float * restrict p_ImagInput2,
	const int count)
{
	int				i;
	float			RealSum, ImagSum;
	ComplexData_t	ReturnValue;

	RealSum = 0.0;
	ImagSum = 0.0;

#if defined (_TMS320C6700)			/* Defined by TI compiler */
#elif ENABLE_SHARC
#pragma SIMD_for
#endif

	for (i = 0; i < count; i ++)
	{
	/* Real components are at even offsets, and imaginary components
	are at odd offsets within each array. */
		RealSum += (p_RealInput1[i] * p_RealInput2[i] -
					p_ImagInput1[i] * p_ImagInput2[i]);
		ImagSum += (p_RealInput1[i] * p_ImagInput2[i] +
					p_ImagInput1[i] * p_RealInput2[i]);
	}
	ReturnValue.real = RealSum;
	ReturnValue.imaginary = ImagSum;

	return (ReturnValue);
	
}


float biquad1 (const float pm * restrict coefs,
	float * restrict state,
	const int numBiquad,
	float y)

{
	int i;
	float sum0;

#if defined (_TMS320C6700)			/* Defined by TI compiler */
_nassert (((int)(coefs) & 0x7) == 0);	/* Float array aligned on 64-bit boundary */
_nassert (((int)(state) & 0x7) == 0);
#pragma MUST_ITERATE (16, , 8);
#elif ENABLE_SHARC
#pragma SIMD_for
#endif

	for (i = 0; i < numBiquad; i++)
	{
		sum0 = coefs[1]*state[1] + coefs[0]*state[0] + y;			// Feedback
		y = coefs[3]*state[1] + coefs[2]*state[0] + sum0;			// Feedforward

		state[1] = state[0];
		state[0] = sum0;

        coefs += 4;  /* point to next filter coefs */
        state += 2;  /* point to next filter states */
	}

	return y;
}



float biquad2 (const float pm * restrict coefs,
	float * restrict state,
	const int numBiquad,
	float y)

{
	register int	i;
	register float	Sum0;
	register float	d0, d1;

#if defined (_TMS320C6700)			/* Defined by TI compiler */
#elif ENABLE_SHARC
#pragma SIMD_for
#endif

	for (i = 0; i < numBiquad; i++)
	{
		d0 = state[2*i+0];
		d1 = state[2*i+1];

		Sum0 = coefs[4*i+1]*d1 + coefs[4*i+0]*d0;				// Feedback

		state[2*i+0] = Sum0 + y;
		state[2*i+1] = d0;

		y += Sum0 + (coefs[4*i+3]*d1 + coefs[4*i+2]*d0);		// Feedforward
	}

	return y;
}


